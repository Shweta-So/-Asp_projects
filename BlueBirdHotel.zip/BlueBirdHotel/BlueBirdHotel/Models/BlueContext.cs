﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace BlueBirdHotel.Models;

public partial class BlueContext : DbContext
{
    public BlueContext()
    {
    }

    public BlueContext(DbContextOptions<BlueContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Payment> Payments { get; set; }

    public virtual DbSet<Room> Rooms { get; set; }

    public virtual DbSet<Roombook> Roombooks { get; set; }

    public virtual DbSet<Signup> Signups { get; set; }

    public virtual DbSet<Staff> Staff { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=127.0.0.1;port=3306;user=root;database=blue", Microsoft.EntityFrameworkCore.ServerVersion.Parse("10.4.32-mariadb"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_general_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Payment>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("payment");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnType("int(30)")
                .HasColumnName("id");
            entity.Property(e => e.Bed).HasMaxLength(30);
            entity.Property(e => e.Bedtotal)
                .HasColumnType("double(8,2)")
                .HasColumnName("bedtotal");
            entity.Property(e => e.Cin).HasColumnName("cin");
            entity.Property(e => e.Cout).HasColumnName("cout");
            entity.Property(e => e.Email).HasMaxLength(30);
            entity.Property(e => e.Finaltotal)
                .HasColumnType("double(8,2)")
                .HasColumnName("finaltotal");
            entity.Property(e => e.Meal)
                .HasMaxLength(30)
                .HasColumnName("meal");
            entity.Property(e => e.Mealtotal)
                .HasColumnType("double(8,2)")
                .HasColumnName("mealtotal");
            entity.Property(e => e.Name).HasMaxLength(30);
            entity.Property(e => e.NoofRoom).HasColumnType("int(30)");
            entity.Property(e => e.Noofdays)
                .HasColumnType("int(30)")
                .HasColumnName("noofdays");
            entity.Property(e => e.RoomType).HasMaxLength(30);
            entity.Property(e => e.Roomtotal)
                .HasColumnType("double(8,2)")
                .HasColumnName("roomtotal");
        });

        modelBuilder.Entity<Room>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("room");

            entity.Property(e => e.Id)
                .HasColumnType("int(30)")
                .HasColumnName("id");
            entity.Property(e => e.Bedding)
                .HasMaxLength(50)
                .HasColumnName("bedding");
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .HasColumnName("type");
        });

        modelBuilder.Entity<Roombook>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("roombook");

            entity.Property(e => e.Id)
                .HasColumnType("int(10)")
                .HasColumnName("id");
            entity.Property(e => e.Bed).HasMaxLength(30);
            entity.Property(e => e.Cin).HasColumnName("cin");
            entity.Property(e => e.Country).HasMaxLength(30);
            entity.Property(e => e.Cout).HasColumnName("cout");
            entity.Property(e => e.Email).HasMaxLength(50);
            entity.Property(e => e.Meal).HasMaxLength(30);
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.Nodays)
                .HasColumnType("int(50)")
                .HasColumnName("nodays");
            entity.Property(e => e.NoofRoom).HasMaxLength(30);
            entity.Property(e => e.Phone).HasMaxLength(30);
            entity.Property(e => e.RoomType).HasMaxLength(30);
            entity.Property(e => e.Stat)
                .HasMaxLength(30)
                .HasColumnName("stat");
        });

        modelBuilder.Entity<Signup>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("signup");

            entity.Property(e => e.Id).HasColumnType("int(30)");
            entity.Property(e => e.Email).HasMaxLength(80);
            entity.Property(e => e.Password).HasMaxLength(100);
            entity.Property(e => e.Username).HasMaxLength(70);
        });

        modelBuilder.Entity<Staff>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("staff");

            entity.Property(e => e.Id)
                .HasColumnType("int(30)")
                .HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(30)
                .HasColumnName("name");
            entity.Property(e => e.Work)
                .HasMaxLength(30)
                .HasColumnName("work");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
