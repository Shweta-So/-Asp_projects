﻿using System;
using System.Collections.Generic;

namespace BlueBirdHotel.Models;

public partial class Roombook
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Country { get; set; } = null!;

    public string Phone { get; set; } = null!;

    public string RoomType { get; set; } = null!;

    public string Bed { get; set; } = null!;

    public string Meal { get; set; } = null!;

    public string NoofRoom { get; set; } = null!;

    public DateOnly Cin { get; set; }

    public DateOnly Cout { get; set; }

    public int Nodays { get; set; }

    public string Stat { get; set; } = null!;
}
