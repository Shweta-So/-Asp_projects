﻿using System;
using System.Collections.Generic;

namespace BlueBirdHotel.Models;

public partial class Room
{
    public int Id { get; set; }

    public string Type { get; set; } = null!;

    public string Bedding { get; set; } = null!;
}
