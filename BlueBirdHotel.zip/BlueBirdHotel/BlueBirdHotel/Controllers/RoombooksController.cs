﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BlueBirdHotel.Models;

namespace BlueBirdHotel.Controllers
{
    public class RoombooksController : Controller
    {
        private readonly BlueContext _context;

        public RoombooksController(BlueContext context)
        {
            _context = context;
        }

        // GET: Roombooks
        public async Task<IActionResult> Index()
        {
              return _context.Roombooks != null ? 
                          View(await _context.Roombooks.ToListAsync()) :
                          Problem("Entity set 'BlueContext.Roombooks'  is null.");
        }

        // GET: Roombooks/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Roombooks == null)
            {
                return NotFound();
            }

            var roombook = await _context.Roombooks
                .FirstOrDefaultAsync(m => m.Id == id);
            if (roombook == null)
            {
                return NotFound();
            }

            return View(roombook);
        }

        // GET: Roombooks/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Roombooks/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Email,Country,Phone,RoomType,Bed,Meal,NoofRoom,Cin,Cout,Nodays,Stat")] Roombook roombook)
        {
            if (ModelState.IsValid)
            {
                _context.Add(roombook);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(roombook);
        }

        // GET: Roombooks/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Roombooks == null)
            {
                return NotFound();
            }

            var roombook = await _context.Roombooks.FindAsync(id);
            if (roombook == null)
            {
                return NotFound();
            }
            return View(roombook);
        }

        // POST: Roombooks/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Email,Country,Phone,RoomType,Bed,Meal,NoofRoom,Cin,Cout,Nodays,Stat")] Roombook roombook)
        {
            if (id != roombook.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(roombook);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RoombookExists(roombook.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(roombook);
        }

        // GET: Roombooks/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Roombooks == null)
            {
                return NotFound();
            }

            var roombook = await _context.Roombooks
                .FirstOrDefaultAsync(m => m.Id == id);
            if (roombook == null)
            {
                return NotFound();
            }

            return View(roombook);
        }

        // POST: Roombooks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Roombooks == null)
            {
                return Problem("Entity set 'BlueContext.Roombooks'  is null.");
            }
            var roombook = await _context.Roombooks.FindAsync(id);
            if (roombook != null)
            {
                _context.Roombooks.Remove(roombook);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool RoombookExists(int id)
        {
          return (_context.Roombooks?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
