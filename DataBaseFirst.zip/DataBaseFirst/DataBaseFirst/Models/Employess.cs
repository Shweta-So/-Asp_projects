﻿using System;
using System.Collections.Generic;

namespace DataBaseFirst.Models;

public partial class Employess
{
    public int Eid { get; set; }

    public string? Empname { get; set; }

    public string? Desig { get; set; }
}
