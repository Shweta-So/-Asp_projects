﻿using Microsoft.AspNetCore.Mvc;

namespace mycontroller.controller
{
    public class HomeController:Controller
    { 
    
        [Route("/")]

        public ContentResult Index()
        {
            return Content("<h1>Nuvrachna</h1>", "text/html");

        //    return new ContentResult
        //    {
        //        Content = "<h1>This is my first content type application ",
        //        ContentType = "text/html",
        //    };
        }
      
        [Route("aboutus")]
        public String About_us()
        {
            return "This is my about us Page";
        }
        [Route("contact")]
        public String Contant_us()
        {
            return "This is my contact us page";
        }
        [Route("/product/{id:int:min(1000):max(9999)}")]
        public String products()
        {
            return "This is my product page";
        }
    }
}
