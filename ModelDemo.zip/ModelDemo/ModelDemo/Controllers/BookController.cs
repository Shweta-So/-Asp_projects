﻿
using Microsoft.AspNetCore.Mvc;
using ModelDemo.Models;
using System.Runtime.Intrinsics.X86;

namespace ModelDemo.Controllers
{
    public class BookController : Controller
    {
       

        [Route("book_valid/{BookId?}/{BookName?}/{author?}/{price?}/{email?}/{password?}")]
        public IActionResult book_validation(Book b1)
        {
            if (b1.BookId.HasValue == false)
            {
                return Content("book id not assign", "text/plain");
            }
            //if (String.IsNullOrEmpty(b1.BookName))
            //{
            //    return BadRequest("Book name is not provided");
            //}
            if (!ModelState.IsValid)
            {
                List<String> errors = new List<String>();
                foreach (var values in ModelState.Values)
                {
                    foreach (var error in values.Errors)
                    {
                        errors.Add(error.ErrorMessage);
                    }
                }

                string errormsg = string.Join("\n", errors);
                return BadRequest(errormsg);
            }
            return Content($"book id is={b1.BookId} \n  book name is:{b1.BookName} \n\n Book Author={b1.author}" +
                $"\n\n  Book Price ={ b1.price}" +
                $"\n\n Book email={b1.email}" +
                $"\n\n Book password={b1.password}"+
                $"\n\n Book cpass={b1.cpass}", "text/plain");



        }
    }
}
        /*
        [Route("/books")]
        public IActionResult Book()
        {
            int? bookid = Convert.ToInt32(Request.Query["bookid"]);
            String? author = Convert.ToString(Request.Query["author"]);
            return Content($"book id is:{bookid} \n book author is: {author}", "text/plain");

        }
        [Route("/book1")]
        //[Route("/books_model/{bookid}/{author}")]
        public IActionResult Book_model(int? bookid, string author)
        {
            if (bookid.HasValue == false)
            {
                return Content("bookid is not provided", "text/plain");
            }
            else
            {
                return Content($"book id is:{bookid} \n book author is:{author}", "text/plain");
            }
        }
        [Route("/book_data/{bookid?}/{author}")]
        public IActionResult book_bind(Book book)
        {
            if (book.BookId.HasValue == false)
            {
                return Content("book is not provided", "text/plain");
            }
            else
            {
                return Content($"book id is: {book.BookId} \n book author is:{book.Author}", "text/plain");
            }
        }
        */
    