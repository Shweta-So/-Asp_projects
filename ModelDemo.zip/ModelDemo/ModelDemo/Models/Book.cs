﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;


namespace ModelDemo.Models
{
    public class Book
    {

        public int? BookId { get; set; }


        [Required(ErrorMessage = "{0}is required")]
        [StringLength(100, MinimumLength = 4, ErrorMessage = "{0} must be given between {2} and {1} character length")]
        [Display(Name = "Book Name")]
        [RegularExpression("^[a-z][A-Z]$", ErrorMessage = "given book name is not vaild")]
        public string? BookName { get; set; }


        [Required(ErrorMessage = "author name must be given")]
        public string? author { get; set; }

        [Range(1, 99.999, ErrorMessage = "price given between 1 to 100")]
        public decimal? price { get; set; }
        [EmailAddress(ErrorMessage = "to enter vaild email")]
        public String email { get; set; }
        public string password { get; set; }
        [Compare("Password",ErrorMessage="password does not match")]
        public string cpass { get; set; }
    }
}
