using Microsoft.AspNetCore.Mvc;
using ModelToView.Models;
using System.Diagnostics;

namespace ModelToView.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            Employee e = new Employee()
            {
                Eid = 1,
                Ename = "shweta",
                Desig = "Manager",
                Salary = 20000
            };

            ViewData["empdata"] = e;
            return View();
        }

        public IActionResult Contact()
        {
            var e1 = new List<Employee>()
            {
                new Employee{Eid=1, Ename="Shweta", Desig="Manager",Salary=2500000},
                new Employee{Eid=2, Ename="Mahek", Desig="Head Officer",Salary=3200000},
                new Employee{Eid=3, Ename="Diya", Desig="Web Developer",Salary=3300000},
            };
            ViewData["empdata"] = e1;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
