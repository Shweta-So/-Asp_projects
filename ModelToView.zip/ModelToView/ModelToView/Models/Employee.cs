﻿namespace ModelToView.Models
{
    public class Employee
    {
        public int? Eid { get; set; }
        public string? Ename { get; set; }
        public string? Desig { get; set; }
        public int? Salary { get; set; }
    }
}
