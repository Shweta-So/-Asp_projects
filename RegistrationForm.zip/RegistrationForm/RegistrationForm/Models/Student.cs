﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace RegistrationForm.Models
{
    public class Student
    {
        [Required(ErrorMessage = "id is must")]
        [Range(1, 50, ErrorMessage = "id must be given between 1 to 50")]
        public int? Sno { get; set; }

        [Required(ErrorMessage = "Name is must")]
        [StringLength(50)]
        public string? Sname { get; set; }

        [Required(ErrorMessage = "address is must")]
        [StringLength(100)]
        public string? Saddress { get; set; }

        [Required(ErrorMessage = "not valid email address")]
        public string? Email { get; set; }

        [Required(ErrorMessage = "password required")]
        public string? Password { get; set; }

        [Compare("Password", ErrorMessage = "password is not match with confirm password")]
        public string? Cpassword { get; set;}

        [StringLength(11, MinimumLength = 10 , ErrorMessage = "To enter maximum 10 digit")]
        public string? Phone { get; set;}
        public string? Gender { get; set; }
        public string? Hobby { get; set; }
        public City City { get; set; }
    }
    public enum City
    {
        Vadodara, Bhuj
    }
    public enum Gender
    {
        Male,Female
    }
}
