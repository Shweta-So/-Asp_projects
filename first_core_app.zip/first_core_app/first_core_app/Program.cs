using first_core_app.Mymiddleware;
using Microsoft.AspNetCore.Http;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddTransient<Mymiddleware>();
var app = builder.Build();

// app.MapGet("/", () => "Shweta Solanki!");


// first middleware
app.Use(async (HttpContext context,RequestDelegate next) =>
{
    await context.Response.WriteAsync("\nHeader part");
    await next(context);
}
);

app.UseMiddleware<Mymiddleware>();

//last middleware
app.Run(async (HttpContext context) =>
 {
      await context.Response.WriteAsync("\nfooter part");
  }
);

app.Run();  