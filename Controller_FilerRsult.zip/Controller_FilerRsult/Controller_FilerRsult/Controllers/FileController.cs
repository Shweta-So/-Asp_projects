﻿
using Microsoft.AspNetCore.Mvc;

namespace Controller_FilerRsult.Controllers
{
    public class FileController : Controller 
    {
        //[Route("file/download")]
        //public VirtualFileResult FileDownload1()
        //{
        //    return new VirtualFileResult("abc.txt", "text/plain");
        //}

        [Route("file2/download")]
        public PhysicalFileResult FileDownload2()
        {
            return new PhysicalFileResult("C:\\abc.txt", "text/plain");
        }

        [Route("file3/download")]
        public FileContentResult FileDownload3()
        {
            byte[] b = System.IO.File.ReadAllBytes("C:\\a1.jpg");
            return new FileContentResult(b,"image/jpg");
        }
    }
}
