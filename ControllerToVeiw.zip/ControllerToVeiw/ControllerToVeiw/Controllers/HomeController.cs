﻿using Microsoft.AspNetCore.Mvc;

namespace ControllerToVeiw.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            //ViewData["name"] = "Asp.net Core";
            ViewBag.name = "Shweta";
            //ViewData["author"] = "Mcgrow Hills";
            ViewBag.author = "Shweta Solanki";
            //ViewData["price"] = 5000;
            ViewBag.price = 1000;

            string[] book_name = { "JAVA", "PHP", "ASP.Net core" };
            ViewBag.book_name = book_name;
            //ViewData["bname"] = book_name;

            ViewBag.list1 = new List<string>()
            {
                "football","cricket","hokey"
            };

            return View();
        }
    }
}
