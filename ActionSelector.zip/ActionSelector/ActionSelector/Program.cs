
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
var app = builder.Build();

app.UseRouting();
app.UseAuthorization();
app.MapControllerRoute(
    name:"default",
    pattern:"{controller=HomeController}/{action=Index}");


app.MapControllerRoute(
    name: "default",
    pattern:"{controller=HomeController}/{action=Index1}");

app.MapControllerRoute(
    name: "default",
    pattern:"{controller=HomeController}/{action=Delete}");

app.MapControllerRoute(
    name: "default",
    pattern:"{controller=HomeController}/{action=Update}");

app.Run();
        