﻿using Microsoft.AspNetCore.Mvc;
namespace ActionSelector.Controllers
{
    public class HomeController : Controller
    {
        [ActionName("i1")]
        public string Index()
        {
            return "This is my index page";
        }
        [ActionName("i2")]
        public string Index1()
        {
            return "This is my sign up page";
        }

        [HttpGet]
        public string Delete() 
        {
            return "Hello from delete method";
        }

        [NonAction]
        public string Update()
        {
            return "Hello from update Method";
        }
    }
}
