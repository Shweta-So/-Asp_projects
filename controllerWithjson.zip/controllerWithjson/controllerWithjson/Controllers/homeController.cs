﻿
using Microsoft.AspNetCore.Mvc;
using controllerWithjson.Models;
namespace controllerWithjson.Controllers
{
    public class homeController:Controller
    {
        [Route("/employee/shweta")]
        public ContentResult employee()
            
        {
            return Content("{\"name\":\"shweta\"}", "application/json");
        }
        [Route("/empdata")]
        public JsonResult emp()
        {
            employee e = new employee()
            {
                Id = 101,
                Name = "Shweta",
                Salary = 50000
            };
            return new JsonResult(e);
        }
    }
}
